prompt --workspace/credentials/app_270978_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 270978 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>90203291867489126727
,p_default_application_id=>270978
,p_default_id_offset=>0
,p_default_owner=>'WKSP_MARIAAPPS'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(90321908986217789987)
,p_name=>'App 270978 Push Notifications Credentials'
,p_static_id=>'App_270978_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
